#!/usr/bin/env node
import { fileURLToPath } from 'node:url';
// npm's bin is a symlink. The unchanged core expects its real file in argv[1].
process.argv[1] = fileURLToPath(new URL('./common/cli.mjs', import.meta.url));
await import('./common/cli.mjs');
