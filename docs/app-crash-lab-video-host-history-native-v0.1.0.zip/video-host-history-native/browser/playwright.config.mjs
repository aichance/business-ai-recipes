import { defineConfig } from '@playwright/test';
import { fileURLToPath } from 'node:url';
const probe = fileURLToPath(new URL('../', import.meta.url));
export default defineConfig({
  testDir: fileURLToPath(new URL('./', import.meta.url)),
  testMatch: 'optional-history.spec.mjs',
  workers: 1, retries: 0, timeout: 35000,
  expect: { timeout: 10000 },
  outputDir: `${probe}/results/browser-artifacts`,
  reporter: [['list'], ['json', { outputFile: `${probe}/results/browser-results.json` }]],
  use: { browserName: 'chromium', serviceWorkers: 'block', headless: true, viewport: { width: 1100, height: 850 } },
  webServer: { command: 'node node_modules/vite/bin/vite.js --config browser/vite.config.mjs', cwd: probe,
    url: 'http://127.0.0.1:54230', reuseExistingServer: false, timeout: 30000 },
});
