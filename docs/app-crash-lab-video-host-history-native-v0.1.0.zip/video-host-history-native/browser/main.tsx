import { Component, useEffect, useMemo, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Provider, useAtomValue } from 'jotai';
import { createMemoryHistory, createRootRoute, createRouter, RouterProvider } from '@tanstack/react-router';
import { Video } from '../upstream/app/frontend/src/components/Player/Shared/Video';
import { watchedHistoryAtom } from '../upstream/app/frontend/src/atoms/WatchedHistory';
import { HlsRefAtom } from '../upstream/app/frontend/src/atoms/Player';

declare global { interface Window { __videoProbe: any; __componentFixture: any; } }
function event(kind: string, value: unknown) {
  window.__videoProbe.events.push({ sequence: ++window.__videoProbe.sequence, kind, value });
}
class FixtureBoundary extends Component<any, { error: { name: string; message: string } | null }> {
  state = { error: null };
  static getDerivedStateFromError(error: Error) { return { error: { name: error.name, message: error.message } }; }
  componentDidCatch(error: Error) {
    const value = { name: error.name, message: error.message };
    window.__componentFixture.error = value;
    event('fixture-boundary-caught', value);
  }
  render() {
    if (this.state.error) return <p data-testid="fixture-error">Fixture boundary caught: {this.state.error.name}: {this.state.error.message}</p>;
    return this.props.children;
  }
}
function Fixture() {
  // Deliberate precondition: hydrate the real atom before mounting Video.
  // Video itself only obtains the history setter; this observer is fixture UI.
  const history = useAtomValue(watchedHistoryAtom);
  const hls = useAtomValue(HlsRefAtom);
  const [mounted, setMounted] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const movie = useMemo(() => ({ id: 'synthetic-video', title: 'Local blue test card',
    variants: [{ id: 'synthetic-variant', contentUrl: `${location.origin}/media/index.m3u8` }], series: null }), []);
  window.__componentFixture = { ...window.__componentFixture, hlsInitialized: hls !== null, history, movie };
  useEffect(() => { event('hls-atom-observed', hls !== null); }, [hls]);
  return <main style={{ maxWidth: 850, margin: '30px auto', fontFamily: 'sans-serif' }}>
    <h1>VideoHost Video component — local synthetic HLS</h1>
    <p>Unchanged source at 14630a0a. Real React, Jotai, Router and Hls. Component fixture only; no backend, authentication or real media.</p>
    <p>The buttons, history observer and error boundary below are fixture UI.</p>
    <button onClick={() => { event('fixture-mount-request', null); setMounted(true); }}>Mount actual Video</button>{' '}
    <button onClick={() => { event('fixture-play-request', null); void videoRef.current?.play().catch((e) => event('play-rejection', { name: e.name, message: e.message })); }}>Play synthetic media</button>{' '}
    <button onClick={() => { if (videoRef.current) { event('fixture-seek-request', 10.2); videoRef.current.currentTime = 10.2; } }}>Seek to 10.2 seconds</button>
    <p data-testid="hls-state">HLS initialized: {String(hls !== null)}</p>
    <FixtureBoundary>{mounted && <Video videoRef={videoRef} movie={movie as any} className="actual-video" />}</FixtureBoundary>
    <h2>Actual history atom (memory; durable storage checked independently)</h2>
    <pre data-testid="history-memory" style={{ whiteSpace: 'pre-wrap' }}>{JSON.stringify(history, null, 2)}</pre>
  </main>;
}
const rootRoute = createRootRoute({ component: Fixture });
const router = createRouter({ routeTree: rootRoute, history: createMemoryHistory({ initialEntries: ['/'] }) });
// No StrictMode: observe the actual component's own effects without dev-only remounts.
createRoot(document.getElementById('root')!).render(<Provider><RouterProvider router={router} /></Provider>);
