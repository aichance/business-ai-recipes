import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath } from 'node:url';
const probe = fileURLToPath(new URL('../', import.meta.url));
export default defineConfig({
  root: fileURLToPath(new URL('./', import.meta.url)),
  plugins: [react()],
  resolve: {
    alias: { '@': fileURLToPath(new URL('../upstream/app/frontend/src', import.meta.url)) },
    dedupe: ['react', 'react-dom', 'jotai', '@tanstack/react-router'],
  },
  server: { host: '127.0.0.1', port: 54230, strictPort: true, fs: { allow: [probe] } },
});
