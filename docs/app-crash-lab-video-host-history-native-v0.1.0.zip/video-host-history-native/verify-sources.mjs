import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const source = JSON.parse(readFileSync(new URL('./SOURCE.json', import.meta.url)));
assert.equal(source.revision, '14630a0abaa8da3badf4525111488d6cb2fd7004');
assert.equal(source.files.length, 8);
for (const file of source.files) {
  assert(!file.path.startsWith('/') && !file.path.split('/').includes('..'));
  const bytes = readFileSync(new URL(`./upstream/${file.path}`, import.meta.url));
  assert.equal(bytes.length, file.bytes, file.path);
  assert.equal(createHash('sha256').update(bytes).digest('hex'), file.sha256, file.path);
  assert.equal(createHash('sha1').update(`blob ${bytes.length}\0`).update(bytes).digest('hex'), file.git_blob, file.path);
}
console.log('Verified eight unchanged pinned VideoHost source/license files.');
