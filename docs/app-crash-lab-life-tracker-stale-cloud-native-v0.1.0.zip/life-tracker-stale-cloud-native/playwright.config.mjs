import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: './tests', fullyParallel: false, workers: 1, retries: 0,
  timeout: 60000, reporter: 'list',
  use: { browserName: 'chromium', viewport: { width: 1280, height: 900 }, trace: 'on' },
  webServer: {
    command: 'node server.mjs', url: 'http://127.0.0.1:54311',
    reuseExistingServer: false, timeout: 120000,
  },
});
