"""Fetch a pinned public app into a NEW directory; do not ship upstream source."""
from pathlib import Path, PurePosixPath
import hashlib
import io
import json
import tarfile
import tempfile
import urllib.request

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'source-manifest.json').read_text())
pin = manifest['pin']
assert pin == '402ad57f75816302fc0cd50cb1a17f78eb78d143'
destination = root / 'app'
if destination.exists() or destination.is_symlink():
    raise SystemExit('app already exists; use a new extracted test-pack folder. Nothing was overwritten.')
url = 'https://codeload.github.com/Adnan9-63/life-tracker/tar.gz/' + pin
request = urllib.request.Request(url, headers={'User-Agent': 'App-Crash-Lab-pinned-source-check'})
with urllib.request.urlopen(request, timeout=60) as response:
    raw = response.read(30_000_001)
assert len(raw) <= 30_000_000, 'Source archive exceeds the download bound'
found = {}
with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
    for item in archive.getmembers():
        if item.isdir():
            continue
        assert item.isfile(), 'Only regular files are accepted'
        parts = PurePosixPath(item.name).parts
        assert parts[0] == 'life-tracker-' + pin and len(parts) > 1
        relative = PurePosixPath(*parts[1:])
        assert not relative.is_absolute() and '..' not in relative.parts
        name = str(relative)
        assert name in manifest['blobs'] and name not in found, 'Unexpected/duplicate file'
        assert item.size == manifest['sizes'][name], 'Unexpected source file size: ' + name
        data = archive.extractfile(item).read()
        digest = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        assert digest == manifest['blobs'][name], 'Source bytes mismatch: ' + name
        found[name] = data
assert set(found) == set(manifest['blobs']), 'Source file list differs from the pinned manifest'
with tempfile.TemporaryDirectory(prefix='.source-check-', dir=root) as temporary:
    staged = Path(temporary) / 'app'
    staged.mkdir()
    for name, data in found.items():
        path = staged / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    assert not destination.exists() and not destination.is_symlink(), 'Destination appeared while downloading'
    staged.rename(destination)
print(f'Verified {len(found)} original public files at {pin}; app/ created locally.')
