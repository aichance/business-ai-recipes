import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('./', import.meta.url));
for (const [command, args] of [
  ['python3', ['download-source.py']],
  ['npm', ['--prefix', 'app', 'ci', '--legacy-peer-deps', '--ignore-scripts', '--no-audit', '--no-fund']],
]) {
  const result = spawnSync(command, args, { cwd: root, stdio: 'inherit', shell: false });
  if (result.error) { console.error(result.error.message); process.exit(1); }
  if (result.status !== 0) process.exit(result.status ?? 1);
}
