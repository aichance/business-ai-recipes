# Life Tracker: older-cloud-response regression

Native `@playwright/test` checks for the real, unmodified Life Tracker UI, hook and Supabase SDK at `402ad57f75816302fc0cd50cb1a17f78eb78d143`.

The test uses a synthetic login and controlled HTTP auth/REST responses on loopback. **No real Supabase account, keys, cloud, RLS, user records, or full physical offline/PWA behavior are tested.** Source files are downloaded from the author's public repository by the setup command and verified against all 35 pinned Git blobs. Upstream application source is not included in this archive. The MIT license here covers our test/setup files only.

## Run

Tested on macOS, Node 22.16.0, Python 3 and Chromium. Use Node 22.12+ and free local ports 54311/54312. Run these commands from the extracted `life-tracker-stale-cloud-native/` folder:

```sh
npm ci --ignore-scripts --no-audit --no-fund
npm run setup
npx playwright install chromium
npm run controls
npm test
```

`setup` creates a NEW `app/` and stops if one already exists. It never overwrites an existing checkout. The app install uses the author's CI flag `--legacy-peer-deps`: plain `npm ci` fails because Vite 8 and the declared PWA plugin peer range conflict. It preserves the original package and lock bytes and skips install scripts. Do not supply real credentials.

The controls pass. On the pinned source, the full suite exits nonzero: two controls pass and the older-remote regression fails. The expected behavior is to retain the new offline edit; it is not hidden behind `test.fail`, skip, or an inverted assertion.

## What it measures

1. Log in through the original UI with synthetic credentials; the original SDK reads a complete baseline record from the controlled endpoint.
2. Edit the tracker name through Settings while the REST service rejects writes. Confirm the actual SDK upsert was rejected, the local record contains the edit, and the UI reports offline storage.
3. Reload while the service still fails: the offline edit must remain (control). The SDK GET path retries after 1, 2 and 4 seconds; the precondition waits for the real fallback.
4. Reload after the service returns the OLD record: the saved offline edit must remain (regression). Compare all five business fields during a bounded 1.6-second observation window and capture the visible title after the response. Keep the first observed loss even if a later write repairs it. On the failing source, the first-loss assertion stops the test before the later cache/UI preservation assertions; the attached checkpoints still record the final cache and title.
5. A separate normal-remote-update control verifies that a successful newer remote row is actually adopted.

`SETUP_FAILED` means a precondition did not complete. An incorrect selector, missing login or unfinished SDK retry must not be counted as the persistence regression. Playwright attaches raw cache checkpoints and a sanitized transport log; trace files stay local.

This is a deterministic client-boundary test, not a real cloud outage, concurrency stress test, auth security assessment or maintainer adoption report. The tested offline change is the profile name; all other business fields are checked for unintended changes. It does not establish every possible edit operation or later retry outcome.

## Use an existing local checkout

Install its original locked dependencies first. Set `LIFE_TRACKER_APP_DIR` to that disposable checkout when running this pack. The server sets ONLY synthetic loopback Supabase values for its own process, and every test starts a new browser context with no inherited session and blocked service workers. Requests outside the local app and synthetic API are blocked. Keep production accounts and data out of the test.

The reusable pattern is: preserve the real client code; control only the remote response boundary; create the newer edit through ordinary UI; verify an actual failed write; then prove that a later successful read does not erase the newer local state. Other applications need their actual protocol, selectors and complete business-record fields adapted together.

Original issue: https://github.com/Adnan9-63/life-tracker/issues/28

App Crash Lab source and other native checks: https://github.com/aichance/business-ai-recipes

If you are the app author and run it on your checkout, report the revision, command result, or first setup blocker. Operator results in this pack do not count as your execution.
