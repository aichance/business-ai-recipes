import { spawn } from 'node:child_process';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(process.env.LIFE_TRACKER_APP_DIR ?? fileURLToPath(new URL('./app', import.meta.url)));
const child = spawn(process.execPath, [resolve(root, 'node_modules/vite/bin/vite.js'),
  '--host', '127.0.0.1', '--port', '54311', '--strictPort'], {
  cwd: root, stdio: 'inherit', env: { ...process.env,
    VITE_SUPABASE_URL: 'http://127.0.0.1:54312',
    VITE_SUPABASE_ANON_KEY: 'synthetic-local-test-anon-key',
  },
});
for (const signal of ['SIGTERM', 'SIGINT']) process.on(signal, () => child.kill(signal));
child.on('error', error => { console.error(error.message); process.exitCode = 1; });
child.on('exit', (code, signal) => { process.exitCode = code ?? (signal ? 1 : 0); });
